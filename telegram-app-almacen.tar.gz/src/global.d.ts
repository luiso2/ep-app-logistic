/// <reference path="./types/telegram.d.ts" />

export {};