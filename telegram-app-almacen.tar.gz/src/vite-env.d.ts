/// <reference types="vite/client" />
/// <reference path="./types/telegram.d.ts" />
